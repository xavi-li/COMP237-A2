'''
@author: Devangini Patel
'''

from Node import Node
from State import State
from collections import deque
from GraphData import *
from TreePlot import TreePlot

#Req.4 - BFS_firstname 
#Req.5 - function arguments: graph_name, initial state name, goal state name
def BFS_YuenKwan(graphName, initialStateName, goalStateName):
    """
    This function performs BFS search using a queue
    """
    
    # Header info for each run
    print()
    print("===================================================")
    print("Graph Name: " + graphName)
    print("Initial State: " + initialStateName)
    print("Goal State: " + goalStateName)
    print()
    
    message = ""
    # Check if graphName exists
    graph = globals().get(graphName)
    if not isinstance(graph, dict):
        message = "The graph_name argument '" + graphName + "' is not a valid dictionary."
        print(message)
        print("Search ended.")
        return 
    
    # Check if initialStateName and goalStateName exist in the graph
    for student in [initialStateName, goalStateName]:
        if student not in graph:
            message += "'" + student + "' does not exist in the graph.\n"
    if message != "":
        print(message)
        print("Search ended.")
        return
    
    #create queue
    queue = deque([]) 
    #since it is a graph, we create visited list
    visited = [] 
    #create root node
    initialState = State(initialStateName) #Req.5
    root = Node(initialState)
    #add to queue and visited list
    queue.append(root)    
    visited.append(root.state.name)
    
    #Req.6 - A flag to check the relationship can be found or not
    relationshipFound = False
    
    # check if there is something in queue to dequeue
    currentNode = root
    while len(queue) > 0:
        
        #get first item in queue
        currentNode = queue.popleft()
        
        print (("-- dequeue --"), currentNode.state.name)
        
        #check if this is goal state
        if currentNode.state.checkGoalState(goalStateName): #Req.5
            print ("reached goal state")
            #print the path
            print ("----------------------")
            print ("Path")
            currentNode.printPath()
            relationshipFound = True #Req.6
            break
        else: 
            relationshipFound = False #Req.6
        
        #get the child nodes 
        childStates = currentNode.state.successorFunction(graph) #Req
        for childState in childStates:
            
            childNode = Node(State(childState))
            
            #check if node is not visited
            if childNode.state.name not in visited:
                
                #add this node to visited nodes
                visited.append(childNode.state.name)
                
                #add to tree and queue
                currentNode.addChild(childNode)
                queue.append(childNode)        

        #show the search tree explored so far
        treeplot = TreePlot()
        treeplot.generateDiagram(root, currentNode)          
               
    if relationshipFound:
        #show the search tree explored so far
        treeplot = TreePlot()
        treeplot.generateDiagram(root, currentNode)  
    else : #Req.6
        print("Relationship cannot be established.")
        print("Search ended.")
    #print tree
    print ("----------------------")
    print ("Tree")
    root.printTree()
    print()



# 1st run
BFS_YuenKwan("connections", "Dolly", "YuenKwan")

# 2nd run
BFS_YuenKwan("connections", "George", "Bob") 

# Req.6: Negative case: relationship cannot be established
BFS_YuenKwan("connections", "Ian", "YuenKwan") 

# Req.7: Negative case: invalid names in arguments
BFS_YuenKwan("invalid_graph_name", "George", "Bob") 

# Req.8: Negative case: names not found
BFS_YuenKwan("connections", "No body", "Everybody") 
