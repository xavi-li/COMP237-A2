'''
@author: Devangini Patel
'''

from GraphData import connections

class State:
    '''
    This class retrieves state information for social connection feature
    '''
    
    def __init__(self, name = None):
        if name == None:
            #create initial state
            self.name = self.getInitialState()
        else:
            self.name = name
    
    #Req.5
    def getInitialState(self, initialStateName):
        initialState = initialStateName   
        return initialState


    #Req.5
    def successorFunction(self, graph):
        """
        This is the successor function. It finds all the persons connected to the
        current person
        """
        return graph[self.name]
        
    #Req.5
    def checkGoalState(self, goalStateName):
        #check if the person's name = goalStateName        
        return self.name == goalStateName 