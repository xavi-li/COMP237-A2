'''
@author: Devangini Patel

Reference: https://www.python.org/doc/essays/graphs/
'''


#create a dictionary with all the mappings
connections = {}
connections["Adam"] = {"Bob", "YuenKwan", "Ema"}
connections["Bob"] = {"Adam", "Dolly", "Ema"}
connections["Dolly"] = {"Bob", "Ema"}
connections["Ema"] = {"Adam", "Bob", "Dolly"}
connections["Frank"] = {"YuenKwan"}
connections["George"] = {"YuenKwan"}
connections["YuenKwan"] = {"Adam", "Frank", "George"}
# below for negative testing cases
connections["Ian"] = {"James"}
connections["James"] = {"Ian"}
